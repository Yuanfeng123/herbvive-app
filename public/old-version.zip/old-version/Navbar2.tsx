'use client'

import Link from 'next/link'
import Image from 'next/image'

const navLinks = [
  { href: '#products', label: '成药商城' },
  { href: '#formula', label: '配方定制' },
  { href: '#process', label: '服务流程' },
  { href: '#contact', label: '联系我们' },
]

export default function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-[200] flex items-center justify-between px-12 h-[72px] bg-white/92 backdrop-blur-[12px] border-b border-border">
      <Link href="/" className="inline-flex items-center no-underline">
        {/* Replace with <Image src="/herbvive.png" alt="HERBVIVE" height={42} width={140} /> when logo is available */}
        {/* <span className="font-serif text-2xl font-light text-ink tracking-wider">HERBVIVE</span> */}
        <Image src="/herbvive.png" alt="HERBVIVE" height={42} width={140} />
      </Link>

      <ul className="flex gap-9 list-none">
        {navLinks.map((link) => (
          <li key={link.href}>
            <Link
              href={link.href}
              className="text-[13px] font-normal tracking-[0.04em] text-ink-soft no-underline transition-colors duration-200 hover:text-sage"
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>

      <Link
        href="#contact"
        className="bg-sage text-white text-[13px] font-medium tracking-[0.04em] px-6 py-[10px] rounded-full no-underline transition-all duration-200 hover:bg-sage-light hover:-translate-y-px"
      >
        医师注册
      </Link>
    </nav>
  )
}
