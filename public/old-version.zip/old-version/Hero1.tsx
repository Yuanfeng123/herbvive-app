'use client'

import Link from 'next/link'
import { useLang } from '@/context/LangContext'
import HeroCanvas from '../HeroCanvas'

function ArrowIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      className="transition-transform duration-300 group-hover:translate-x-0.5"
      aria-hidden
    >
      <path d="M5 12h14M12 5l7 7-7 7" />
    </svg>
  )
}

export default function Hero() {
  const { t } = useLang()

  return (
    <section className="hero-interactive min-h-[100dvh] pt-[108px] flex flex-col bg-sage-ultra relative overflow-hidden">
      <HeroCanvas />

      <div className="relative z-10 text-center px-5 sm:px-8 lg:px-12 pt-8 sm:pt-10 lg:pt-12 pb-6 sm:pb-8 animate-fadeUp">
        <span className="inline-block text-[11px] font-medium tracking-[0.12em] uppercase text-sage bg-sage-pale border border-border px-4 py-1.5 rounded-full mb-8">
          Professional TCM · 专业草本
        </span>
        <h1 className="font-serif text-[clamp(42px,6vw,72px)] font-light leading-[1.15] text-ink tracking-[-0.01em] mb-4">
          面向执业医师的<br />
          <em className="not-italic text-sage">专业草本平台</em>
        </h1>
        <p className="text-base text-ink-soft font-light leading-relaxed max-w-xl mx-auto">
          成药商城 · 配方定制 · 次日达配送 · 全美覆盖
        </p>
      </div>

      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-5 pb-20 sm:pb-28 min-h-[180px] animate-fadeUp animation-delay-300">
        <Link
          href="/contact"
          className="group relative inline-flex items-center justify-center gap-2.5 bg-sage text-white text-[15px] sm:text-[16px] font-medium tracking-[0.02em] px-10 py-4 sm:px-14 sm:py-[18px] rounded-full no-underline
            shadow-[0_6px_28px_rgba(74,124,89,0.32)] ring-2 ring-white/40 ring-offset-2 ring-offset-sage-ultra
            transition-all duration-300 ease-out
            hover:bg-sage-light hover:shadow-[0_10px_36px_rgba(74,124,89,0.42)] hover:-translate-y-1
            active:translate-y-0 active:shadow-[0_4px_20px_rgba(74,124,89,0.28)]
            focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sage focus-visible:ring-offset-2"
        >
          <span className="relative z-10">{t('立即注册体验', 'Register to try')}</span>
          <ArrowIcon />
        </Link>
        <p className="mt-5 text-[13px] sm:text-[14px] text-ink-soft font-light leading-relaxed text-center max-w-sm">
          {t('免费开通医师账号，专属顾问协助上手', 'Open a physician account — we help you get started')}
        </p>
      </div>
    </section>
  )
}
